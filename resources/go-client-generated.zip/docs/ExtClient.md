# ExtClient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | **string** |  | [optional] [default to null]
**Address6** | **string** |  | [optional] [default to null]
**AllowedIps** | **[]string** |  | [optional] [default to null]
**Clientid** | **string** |  | [optional] [default to null]
**Deniednodeacls** | **map[string]interface{}** |  | [optional] [default to null]
**Dns** | **string** |  | [optional] [default to null]
**Enabled** | **bool** |  | [optional] [default to null]
**Extraallowedips** | **[]string** |  | [optional] [default to null]
**Ingressgatewayendpoint** | **string** |  | [optional] [default to null]
**Ingressgatewayid** | **string** |  | [optional] [default to null]
**Lastmodified** | **int64** |  | [optional] [default to null]
**Network** | **string** |  | [optional] [default to null]
**Ownerid** | **string** |  | [optional] [default to null]
**Postdown** | **string** |  | [optional] [default to null]
**Postup** | **string** |  | [optional] [default to null]
**Privatekey** | **string** |  | [optional] [default to null]
**Publickey** | **string** |  | [optional] [default to null]
**RemoteAccessClientId** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


