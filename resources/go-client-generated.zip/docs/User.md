# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Isadmin** | **bool** |  | [optional] [default to null]
**Issuperadmin** | **bool** |  | [optional] [default to null]
**LastLoginTime** | [**time.Time**](time.Time.md) |  | [optional] [default to null]
**Password** | **string** |  | [optional] [default to null]
**RemoteGwIds** | **map[string]interface{}** |  | [optional] [default to null]
**Username** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


