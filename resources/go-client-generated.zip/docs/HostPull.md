# HostPull

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ChangeDefaultGw** | **bool** |  | [optional] [default to null]
**DefaultGwIp** | **string** |  | [optional] [default to null]
**EgressNetworkRoutes** | [**[]EgressNetworkRoutes**](EgressNetworkRoutes.md) |  | [optional] [default to null]
**EndpointDetection** | **bool** |  | [optional] [default to null]
**FwUpdate** | [***FwUpdate**](FwUpdate.md) |  | [optional] [default to null]
**Host** | [***Host**](Host.md) |  | [optional] [default to null]
**HostNetworkInfo** | [***HostInfoMap**](HostInfoMap.md) |  | [optional] [default to null]
**IsInetGw** | **bool** |  | [optional] [default to null]
**Nodes** | [**[]Node**](Node.md) |  | [optional] [default to null]
**PeerIds** | [***PeerMap**](PeerMap.md) |  | [optional] [default to null]
**Peers** | [**[]PeerConfig**](PeerConfig.md) |  | [optional] [default to null]
**ServerConfig** | [***ServerConfig**](ServerConfig.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


