# Network

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Addressrange** | **string** |  | [optional] [default to null]
**Addressrange6** | **string** |  | [optional] [default to null]
**Allowmanualsignup** | **string** |  | [optional] [default to null]
**Defaultacl** | **string** |  | [optional] [default to null]
**Defaultinterface** | **string** |  | [optional] [default to null]
**Defaultkeepalive** | **int32** |  | [optional] [default to null]
**Defaultlistenport** | **int32** |  | [optional] [default to null]
**Defaultmtu** | **int32** |  | [optional] [default to null]
**Defaultpostdown** | **string** |  | [optional] [default to null]
**Defaultudpholepunch** | **string** |  | [optional] [default to null]
**Isipv4** | **string** |  | [optional] [default to null]
**Isipv6** | **string** |  | [optional] [default to null]
**Netid** | **string** |  | [optional] [default to null]
**Networklastmodified** | **int64** |  | [optional] [default to null]
**Nodelimit** | **int32** |  | [optional] [default to null]
**Nodeslastmodified** | **int64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


