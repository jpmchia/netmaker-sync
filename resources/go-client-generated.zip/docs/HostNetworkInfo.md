# HostNetworkInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Interfaces** | [**[]Iface**](Iface.md) |  | [optional] [default to null]
**IsStatic** | **bool** |  | [optional] [default to null]
**ListenPort** | **int64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


