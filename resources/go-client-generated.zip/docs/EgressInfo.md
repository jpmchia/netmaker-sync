# EgressInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EgressGatewayCfg** | [***EgressGatewayRequest**](EgressGatewayRequest.md) |  | [optional] [default to null]
**EgressGwAddr** | [***IpNet**](IPNet.md) |  | [optional] [default to null]
**EgressId** | **string** |  | [optional] [default to null]
**Network** | [***IpNet**](IPNet.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


