# CustomExtClient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Clientid** | **string** |  | [optional] [default to null]
**Deniednodeacls** | **map[string]interface{}** |  | [optional] [default to null]
**Dns** | **string** |  | [optional] [default to null]
**Enabled** | **bool** |  | [optional] [default to null]
**Extraallowedips** | **[]string** |  | [optional] [default to null]
**Postdown** | **string** |  | [optional] [default to null]
**Postup** | **string** |  | [optional] [default to null]
**Publickey** | **string** |  | [optional] [default to null]
**RemoteAccessClientId** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


