# RelayRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Netid** | **string** |  | [optional] [default to null]
**Nodeid** | **string** |  | [optional] [default to null]
**Relayaddrs** | **[]string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


