# Signal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Action** | [***SignalAction**](SignalAction.md) |  | [optional] [default to null]
**FromHostId** | **string** |  | [optional] [default to null]
**FromHostPubkey** | **string** |  | [optional] [default to null]
**FromNodeId** | **string** |  | [optional] [default to null]
**IsPro** | **bool** |  | [optional] [default to null]
**Reply** | **bool** |  | [optional] [default to null]
**Server** | **string** |  | [optional] [default to null]
**Timestamp** | **int64** |  | [optional] [default to null]
**ToHostId** | **string** |  | [optional] [default to null]
**ToHostPubkey** | **string** |  | [optional] [default to null]
**ToNodeId** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


